#!/usr/bin/env python3
"""Убрать у установщика Windows оба лишних вопроса.

  ./fix-msi-prompts.py <путь-к-форку>

ЗАЧЕМ. Владелец увидел при установке ДВА окна подряд и спросил про оба:

  1. «The following applications should be closed before continuing the
     install: ЯдроЧат» — приложение запущено, и установщик спрашивает,
     закрыть ли его.
  2. «You must restart your system…» — установщик планирует замену занятых
     файлов после перезагрузки.

Оба — поведение Windows Installer ПО УМОЛЧАНИЮ, а не поломка сборки, и у
обоих одна причина: файл занят запущенным приложением. Для программы, которая
живёт в своей папке и ничего в системе не регистрирует, ни вопрос, ни
перезагрузка не нужны.

Лечится по-разному, и оба лечения нужны вместе:

  * приложение закрывается САМО, до проверки занятых файлов
    (`util:CloseApplication` — посылает окну WM_CLOSE). Тогда к моменту
    проверки занимать нечего, и первое окно не появляется;
  * перезагрузка не планируется и о ней не спрашивают (`REBOOT`).

Одного первого мало: закрыть можно не всё (папку держит проводник,
антивирус читает каталог), и тогда всплывёт второе окно.

ПОЧЕМУ ОТДЕЛЬНЫМ СКРИПТОМ, А НЕ В apply-desktop.sh. Правится не форк, а
ЧУЖОЙ ПАКЕТ (`app-builder-lib`), из шаблона которого electron-builder собирает
.wxs. Пакет приезжает `npm ci`, то есть ПОСЛЕ брендинга, и правка, сделанная
раньше, была бы стёрта установкой зависимостей. Отсюда и место вызова —
шаг конвейера сразу за `npm ci`.

ПОЧЕМУ НЕ ЧЕРЕЗ patch-package, которым форк правит другие пакеты. У него
ОДИН файл заплатки на пакет, и `app-builder-lib+26.6.0.patch` у вендора уже
занят своим. Дописывать в чужую заплатку свой кусок значит держать diff,
который ломается от любого обновления вендора — молча и в момент сборки.

ЧТО ИМЕННО ДЕЛАЕМ.

  `REBOOT=ReallySuppress` — штатный способ MSI сказать «перезагрузку не
  планировать и о ней не спрашивать».

  `util:CloseApplication` — закрывает наше окно ДО того, как установщик
  начнёт считать занятые файлы. `CloseMessage="yes"` шлёт окну обычное
  «закройся» (WM_CLOSE), а не убивает процесс: несохранённого у мессенджера
  нет, но грубое завершение оставило бы за собой мусор в профиле Electron.
  `RebootPrompt="no"` — не спрашивать о перезагрузке, даже если закрыть не
  удалось.

  Расширение `WixUtilExtension`, откуда берётся `CloseApplication`, уже
  подключено к обеим стадиям сборки (`additionalWixArgs` в
  `electron-builder.ts` попадает и в candle, и в light) и лежит в комплекте
  WiX, который качает electron-builder, — проверено разбором архива.

ЧЕГО ЭТО НЕ ГАРАНТИРУЕТ: файл может держать не наше окно, а проводник или
антивирус. Тогда закрыть нечего, и работает второе средство — перезагрузку
всё равно не спросят.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Скрипт объясняется по-русски, а кодировку вывода питон берёт У КОНСОЛИ: на
# раннере Windows это cp1252, и первая же русская строка уронила бы его
# UnicodeEncodeError-ом уже ПОСЛЕ правки файла (урок CLAUDE.md).
for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass

TEMPLATE = Path("node_modules/app-builder-lib/templates/msi/template.xml")

# Якорь — строка САМОГО ВЕНДОРА, а не то, что вставляем мы. Признак
# применённости — тоже наш собственный текст, которого в шаблоне нет: отметка,
# которую ставит сама правка, отменяет проверку, а не выполняет её.
ANCHOR = '    <Property Id="DISABLEADVTSHORTCUTS" Value="1"/>\n'
APPLIED = 'Id="REBOOT"'

# Пространство имён расширения — от СХЕМЫ шаблона (v4), а не от WiX 3
# (`schemas.microsoft.com/wix/UtilExtension`). Взято из самой библиотеки
# разбором строк, а не по памяти.
WIX_TAG = '<Wix xmlns="http://wixtoolset.org/schemas/v4/wxs">'
WIX_TAG_NEW = ('<Wix xmlns="http://wixtoolset.org/schemas/v4/wxs"\n'
               '     xmlns:util="http://wixtoolset.org/schemas/v4/wxs/util">')
def insert(executable: str) -> str:
    return (
        '    <!-- ЯдроЧат: не планировать перезагрузку и не спрашивать о ней.\n'
        '         Приложение живёт в своей папке и ничего в системе не\n'
        '         регистрирует — перезагрузка не нужна. -->\n'
        '    <Property Id="REBOOT" Value="ReallySuppress"/>\n'
        '\n'
        '    <!-- ЯдроЧат: закрыть приложение САМИМ установщиком, до подсчёта\n'
        '         занятых файлов. Иначе Windows спрашивает «закрыть ЯдроЧат?»\n'
        '         при каждой переустановке. CloseMessage шлёт окну обычное\n'
        '         «закройся», а не убивает процесс. -->\n'
        f'    <util:CloseApplication\n'
        f'        Id="CloseYadroChat"\n'
        f'        Target="{executable}"\n'
        f'        CloseMessage="yes"\n'
        f'        RebootPrompt="no"/>\n'
    )


def read_executable(fork: Path) -> str:
    """Имя исполняемого файла — ИЗ brand.env, а не строкой здесь.

    Вторая запись имени разошлась бы с первой на первом же ребрендинге, и
    установщик молча перестал бы находить окно, которое закрывает: отказа
    при этом нет — просто снова появляется вопрос.
    """
    env = Path(__file__).resolve().parent / "brand.env"
    for line in env.read_text(encoding="utf-8").splitlines():
        key, _, value = line.partition("=")
        if key.strip() == "BRAND_NAME_LATIN":
            return value.strip().strip('"').strip("'") + ".exe"
    raise SystemExit(f"ОТКАЗ: в {env} нет BRAND_NAME_LATIN")


def main() -> int:
    if len(sys.argv) != 2:
        print("Использование: ./fix-msi-prompts.py <путь-к-форку>", file=sys.stderr)
        return 1

    fork = Path(sys.argv[1])
    path = fork / TEMPLATE
    if not path.is_file():
        print(f"ОТКАЗ: нет {path}", file=sys.stderr)
        print("Зависимости ещё не установлены либо раскладка пакета изменилась.", file=sys.stderr)
        print("Скрипт зовётся ПОСЛЕ `npm ci` — проверьте порядок шагов.", file=sys.stderr)
        return 1

    text = path.read_text(encoding="utf-8")

    if APPLIED in text:
        print("  лишние вопросы установщика уже сняты")
        return 0

    if ANCHOR not in text or WIX_TAG not in text:
        print(f"ОТКАЗ: в {path} не найдено место для правки.", file=sys.stderr)
        print("Апстрим изменил шаблон MSI. Пропустить нельзя: установщик", file=sys.stderr)
        print("снова начнёт спрашивать про закрытие приложения и перезагрузку.", file=sys.stderr)
        return 1

    executable = read_executable(fork)
    text = text.replace(WIX_TAG, WIX_TAG_NEW, 1)
    text = text.replace(ANCHOR, ANCHOR + insert(executable), 1)
    path.write_text(text, encoding="utf-8")
    print(f"  сняты лишние вопросы установщика (REBOOT + закрытие {executable})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
