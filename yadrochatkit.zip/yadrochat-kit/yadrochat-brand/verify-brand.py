#!/usr/bin/env python3
"""Заслон сборки ЯдроЧата: доказать, что бренд применён.

    python yadrochat-verify-brand.py [путь-к-форку]

Один файл на ОБА форка — десктопный (`mattermost/desktop`) и мобильный
(`mattermost-mobile`). Тип форка определяется по его раскладке, и проверки
запускаются свои. Две отдельные копии разошлись бы на первой же правке, а
расходиться им нельзя: они отвечают на один вопрос.

Копируется в форк скриптами `branding/apply-desktop.sh` и `apply-mobile.sh`,
запускается из workflow перед сборкой. Живёт в форке, а не в «Ядре»,
намеренно: CI форка не имеет доступа к приватному репозиторию «Ядра», а
проверка обязана идти в каждой сборке.

ЗАЧЕМ. Сценарий отказа реальный и тихий: подтянули апстрим, `git merge` вернул
вендорские файлы, `apply-desktop.sh` и `make-desktop-icons.py` прогнать забыли.
Сборка проходит, устанавливается, запускается — и носит имя, логотип и адреса
обновлений Mattermost. Узнаётся это у пользователя, а не в CI.

Только stdlib: на раннере нет ни cairosvg, ни pillow, и ставить их ради
проверки нечего — она сверяет ХЕШИ, а не рисует.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys

# Заслон объясняется по-русски, а кодировку вывода питон берёт У КОНСОЛИ: на
# раннере Windows это `cp1252`, кириллицы в ней нет, и печать собственного
# вердикта роняла бы заслон трассировкой UnicodeEncodeError. Отказ выглядел бы
# отказом БРЕНДА — то есть называл бы не свою причину.
#
# Чинит себя сам скрипт, а не окружение вызвавшего: его зовут из двух
# конвейеров и с рук, и правило «вывод не зависит от кодировки чужой консоли»
# принадлежит ему. `errors="replace"` — чтобы редкая экзотика в чужом пути
# портила букву, а не роняла проверку.
for _stream in (sys.stdout, sys.stderr):
    reconfigure = getattr(_stream, "reconfigure", None)
    if reconfigure is not None:
        reconfigure(encoding="utf-8", errors="replace")
from pathlib import Path

MANIFEST_NAME = "yadrochat-icons.json"

errors: list[str] = []
notes: list[str] = []


def fail(msg: str) -> None:
    errors.append(msg)


def check_text_settings(fork: Path) -> None:
    """Имя, идентификатор и адреса — то, что видно пользователю и юристу."""
    pkg_path = fork / "package.json"
    if not pkg_path.is_file():
        fail("нет package.json — это точно форк mattermost/desktop?")
        return

    pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
    product = pkg.get("productName", "")
    if not product or product.lower() == "mattermost":
        fail(f"package.json: productName = {product!r} — бренд не применён")
    if "mattermost" in str(pkg.get("homepage", "")).lower():
        fail("package.json: homepage ведёт на сайт вендора")

    builder = fork / "electron-builder.ts"
    if builder.is_file():
        text = builder.read_text(encoding="utf-8")
        for m in re.finditer(r"appId:\s*'([^']+)'", text):
            if "mattermost" in m.group(1).lower():
                fail(f"electron-builder.ts: appId = {m.group(1)!r} — идентификатор вендора")
    else:
        fail("нет electron-builder.ts — раскладка апстрима изменилась")

    build_config = fork / "src" / "common" / "config" / "buildConfig.ts"
    if build_config.is_file():
        text = build_config.read_text(encoding="utf-8")
        # Самое дорогое из забытого: адрес обновлений вендора зовёт наших
        # сотрудников поставить ЕГО сборку поверх нашей.
        for pattern, what in (
            (r"updateNotificationURL:\s*'[^']*mattermost[^']*'", "updateNotificationURL"),
            (r"linuxGitHubReleaseURL:\s*'[^']*mattermost[^']*'", "linuxGitHubReleaseURL"),
            (r"macAppStoreUpdateURL:\s*'[^']*mattermost[^']*'", "macAppStoreUpdateURL"),
        ):
            if re.search(pattern, text):
                fail(f"buildConfig.ts: {what} остался вендорским — сборка позовёт на чужое обновление")
        if not re.search(r"defaultServers:\s*\[\s*\{", text):
            fail("buildConfig.ts: defaultServers пуст — приложение спросит адрес сервера у сотрудника")
    else:
        fail("нет src/common/config/buildConfig.ts — раскладка апстрима изменилась")


def check_mobile_settings(fork: Path) -> None:
    """Мобильный форк: имя, идентификатор, сервер и телеметрия вендора."""
    app_json = fork / "app.json"
    if app_json.is_file():
        app = json.loads(app_json.read_text(encoding="utf-8"))
        for key in ("name", "displayName"):
            if str(app.get(key, "")).lower() == "mattermost":
                fail(f"app.json: {key} = {app.get(key)!r} — бренд не применён")
    else:
        fail("нет app.json — раскладка апстрима изменилась")

    override = fork / "assets" / "override" / "config.json"
    if override.is_file():
        cfg = json.loads(override.read_text(encoding="utf-8"))
        if not cfg.get("DefaultServerUrl"):
            fail("assets/override/config.json: не задан DefaultServerUrl — "
                 "приложение спросит адрес сервера у сотрудника")
        # Умолчание апстрима враждебно: в релизных настройках Sentry включён
        # на ЕГО организацию, то есть отчёты о падениях нашего корпоративного
        # клиента уходили бы наружу (ФЗ-152).
        if cfg.get("SentryEnabled"):
            fail("assets/override/config.json: SentryEnabled — телеметрия уйдёт вендору")
    else:
        fail("нет assets/override/config.json — брендинг мобильного не применён")

    for name in (".env.ios.release", ".env.android.release"):
        env_file = fork / "fastlane" / name
        if not env_file.is_file():
            fail(f"нет fastlane/{name} — раскладка апстрима изменилась")
            continue
        text = env_file.read_text(encoding="utf-8")
        for key in ("MAIN_APP_IDENTIFIER", "APP_NAME", "APP_SCHEME"):
            m = re.search(rf"^{key}=(.*)$", text, re.M)
            if m is None:
                fail(f"fastlane/{name}: нет {key}")
            elif "mattermost" in m.group(1).strip().lower():
                fail(f"fastlane/{name}: {key} = {m.group(1).strip()!r} — значение вендора")
        if re.search(r"^SENTRY_ENABLED=true", text, re.M):
            fail(f"fastlane/{name}: SENTRY_ENABLED=true — отчёты уйдут вендору")


def check_icons(fork: Path, assets: Path) -> None:
    """Иконки сверяются ХЕШАМИ по манифесту.

    Проверка текста иконок не видит вовсе: файлы бинарные, а `git merge`
    апстрима откатывает их молча. Манифест — наш файл, слияние его не удаляет,
    поэтому расхождение хешей и означает «ассеты вернулись к вендорским».
    """
    manifest_path = assets / MANIFEST_NAME
    if not manifest_path.is_file():
        fail(
            f"нет {manifest_path.relative_to(fork)} — иконки не собирались.\n"
            "      Прогоните генератор иконок из branding/ (make-icons.sh для\n"
            "      мобильного, make-desktop-icons.py для десктопа)"
        )
        return

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files = manifest.get("files") or {}
    if not files:
        fail("манифест иконок пуст")
        return

    changed: list[str] = []
    missing: list[str] = []
    for rel, expected in files.items():
        path = assets / rel
        if not path.is_file():
            missing.append(rel)
            continue
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            changed.append(rel)

    if missing:
        fail(f"иконок нет ({len(missing)}): {', '.join(sorted(missing)[:4])}…")
    if changed:
        fail(
            f"иконки разошлись с манифестом ({len(changed)}): "
            f"{', '.join(sorted(changed)[:4])}…\n"
            "      Обычно это откат ассетов слиянием апстрима.\n"
            "      Лечится повторным прогоном генератора иконок"
        )
    if not missing and not changed:
        notes.append(f"иконки на месте и не менялись: {len(files)} файлов")


def main() -> int:
    fork = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()

    # Тип форка — по его раскладке, а не по флагу в командной строке: флаг
    # можно передать неверный, и проверка молча пройдёт не по тому набору.
    is_desktop = (fork / "electron-builder.ts").is_file()
    is_mobile = (fork / "fastlane" / "Fastfile").is_file() and (fork / "app.json").is_file()

    if is_desktop:
        notes.append("форк: десктоп")
        check_text_settings(fork)
        check_icons(fork, fork / "src" / "assets")
        checked = "имя, идентификатор и адреса обновлений — наши"
    elif is_mobile:
        notes.append("форк: мобильный")
        check_mobile_settings(fork)
        check_icons(fork, fork / "assets" / "override")
        checked = "имя, идентификатор, сервер по умолчанию — наши; телеметрия вендора выключена"
    else:
        checked = ""
        fail(
            "не удалось определить тип форка: нет ни electron-builder.ts\n"
            "      (десктоп), ни fastlane/Fastfile + app.json (мобильный)"
        )

    if errors:
        print("БРЕНД НЕ ПРИМЕНЁН — сборка остановлена\n", file=sys.stderr)
        for err in errors:
            print(f"  - {err}", file=sys.stderr)
        print(
            "\nПочему это отказ, а не предупреждение: собранное приложение "
            "\nустановится и запустится, нося имя и адреса вендора. Заметят это "
            "\nу пользователя, а не здесь.",
            file=sys.stderr,
        )
        return 1

    print("Бренд применён:")
    for note in notes:
        print(f"  - {note}")
    print(f"  - {checked}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
