#!/usr/bin/env bash
# Применить бренд ЯдроЧата к форку mattermost/desktop (Electron).
#
#   ./apply-desktop.sh <путь-к-форку>
#
# Идемпотентен. Запускать ПОСЛЕ каждого подтягивания апстрима.
#
# Правятся три файла:
#   package.json                     — имя продукта, издатель, адреса
#   src/common/config/buildConfig.ts — сервер по умолчанию и адреса обновлений
#   electron-builder.ts              — appId сборки
#
# buildConfig.ts у апстрима так и подписан: «Build-time configuration. End-users
# can't change these parameters» — это штатная точка ребрендинга, а не наша
# самодеятельность.
#
# ОСОБО: у вендора там прописан СВОЙ адрес обновлений
# (releases.mattermost.com). Оставить его — значит звать наших сотрудников
# обновиться на сборку вендора, которая к нашему серверу не привязана. Скрипт
# снимает это обязательно, а не по желанию.
set -euo pipefail

# Питон печатает по-русски, а кодировку вывода берёт У КОНСОЛИ. На раннере
# Windows это `cp1252`, кириллицы в ней нет, и скрипт падал на СОБСТВЕННОМ
# сообщении об успехе («правлен package.json») — UnicodeEncodeError с
# трассировкой вместо строки о проделанной работе. Отказ при этом выглядел
# отказом БРЕНДИНГА, хотя правка файла к тому моменту уже прошла.
#
# Ставится здесь, а не в конвейере сборки: скрипт зовут и руками, и с чужой
# машины, и правило «вывод не зависит от кодировки чужой консоли» принадлежит
# ему самому. UTF-8 mode заодно чинит и ЧТЕНИЕ файлов без явной кодировки.
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8

# Путь к форку разрешается в АБСОЛЮТНЫЙ до того, как скрипт уйдёт в свой
# каталог. Иначе относительный аргумент начинает считаться от каталога скрипта:
# вызов `bash yadrochat-brand/apply-desktop.sh .` (ровно так его зовёт CI при
# работе из комплекта) искал бы форк ВНУТРИ комплекта и отказывал с «в форке
# нет package.json». Сборка при этом краснела бы на верном форке.
FORK="${1:-}"
[ -n "$FORK" ] || { echo "Использование: ./apply-desktop.sh <путь-к-форку-desktop>" >&2; exit 1; }
[ -d "$FORK" ] || { echo "ОТКАЗ: нет каталога $FORK" >&2; exit 1; }
FORK="$(cd "$FORK" && pwd)"

cd "$(dirname "$0")"
BRAND_DIR="$PWD"

# shellcheck source=brand.env
. "$BRAND_DIR/brand.env"

BUILD_CONFIG="src/common/config/buildConfig.ts"
MAIN_PAGE="src/renderer/components/MainPage.tsx"
RENDERER_CSS="src/renderer/css/index.scss"
LOADING_ICON="src/renderer/components/LoadingAnimation/LoadingIcon.tsx"
CHAT_VIEW="src/app/views/MattermostWebContentsView.ts"
STYLE_FILE="src/app/views/yadrochatStyle.ts"
for f in package.json "$BUILD_CONFIG" electron-builder.ts scripts/afterpack.js \
         webpack.config.renderer.js "$MAIN_PAGE" "$RENDERER_CSS" "$LOADING_ICON" \
         "$CHAT_VIEW"; do
    [ -f "$FORK/$f" ] || {
        echo "ОТКАЗ: в форке нет $f — раскладка апстрима изменилась." >&2
        echo "Сверьтесь с апстримом и почините пути здесь; молча пропустить нельзя:" >&2
        echo "сборка выйдет с брендом вендора." >&2
        exit 1
    }
done

APP_SCHEME="$(printf '%s' "$BRAND_NAME_LATIN" | tr '[:upper:]' '[:lower:]')"

# --- package.json -------------------------------------------------------------
python3 - "$FORK/package.json" <<PY
import json, sys

path = sys.argv[1]
with open(path, encoding="utf-8") as f:
    pkg = json.load(f)

pkg["name"] = "${APP_SCHEME}-desktop"
pkg["productName"] = "${BRAND_NAME}"
pkg["description"] = "${BRAND_DESCRIPTION}"
pkg["author"] = "${BRAND_VENDOR} <${BRAND_SUPPORT_EMAIL}>"
pkg["homepage"] = "${BRAND_SUPPORT_URL}"

with open(path, "w", encoding="utf-8") as f:
    json.dump(pkg, f, ensure_ascii=False, indent=2)
    f.write("\n")
print("  правлен package.json")
PY

# --- buildConfig.ts и electron-builder.ts -------------------------------------
# Замены ТОЧЕЧНЫЕ и с проверкой попадания. Переписать файл целиком нельзя: при
# обновлении апстрима мы бы молча потеряли его новые поля. Но и «заменить, если
# найдётся» нельзя тоже — непопавшая замена оставила бы адрес вендора в сборке
# и ничего не сказала. Поэтому каждая замена ОБЯЗАНА совпасть, иначе отказ.
python3 - "$FORK/$BUILD_CONFIG" "$FORK/electron-builder.ts" "$FORK/scripts/afterpack.js" \
         "$FORK/webpack.config.renderer.js" "$FORK/$MAIN_PAGE" "$FORK/$CHAT_VIEW" <<PY
import re, sys

build_config, electron_builder, afterpack = sys.argv[1], sys.argv[2], sys.argv[3]
webpack_renderer, main_page, chat_view = sys.argv[4], sys.argv[5], sys.argv[6]

AUTH_GATE = """
    /**
     * Уход на форму входа Mattermost — это наш экран входа.
     *
     * Вход в ЯдроЧат идёт по номеру телефона (ADR-002), и штатной формы с
     * почтой и паролем сотрудник видеть не должен: пароля у него нет вовсе.
     *
     * Сверяется ПУТЬ, а не ссылка целиком: у неё бывает хвост
     * (?redirect_to=...), и сравнение целиком промахивалось бы.
     *
     * Адрес нашего экрана берётся ИЗ ТОГО ЖЕ РАЗБОРА — origin страницы, на
     * которой мы стоим. Не из настроек сервера: мы уже стоим на его /login,
     * то есть origin заведомо верен и заведомо есть. Спрашивать его у
     * ServerManager значит завести путь, на котором ответа может не быть.
     */
    private handleAuthGate = () => {
        const current = this.webContentsView.webContents.getURL();
        if (!current) {
            return;
        }
        let parsed: URL;
        try {
            parsed = new URL(current);
        } catch (e) {
            return;
        }
        const path = parsed.pathname.replace(/\\/+$/, '');
        if (path !== '/login' && path !== '/signup_email') {
            return;
        }
        this.webContentsView.webContents.loadURL(parsed.origin + '/vhod/');
    };

"""
failures = []

def patch(path, rules, count=1):
    """Точечные правки файла. count=0 — заменить ВСЕ вхождения.

    Правило — тройка (шаблон, замена, что это) либо ЧЕТВЁРКА с явным
    признаком «уже применено».

    Признак нужен ВСТАВКАМ (шаблон в lookbehind, замена дописывает строку):
    у них шаблон совпадает и на уже правленом файле, поэтому без признака
    строка дописывается ЗАНОВО каждый прогон. Поймано живым прогоном:
    подписка на события чата встала в файл дважды.

    Догадка по первой строке замены для вставок не годится тоже — у них она
    начинается с общего для файла кода (\`this.webContentsView.webContents.on\`),
    и непопавшая замена молча сходит за применённую.
    """
    with open(path, encoding="utf-8") as f:
        text = f.read()

    for rule in rules:
        pattern, replacement, what = rule[0], rule[1], rule[2]
        applied = rule[3] if len(rule) > 3 else None

        if applied is not None and applied in text:
            continue

        text, n = re.subn(pattern, replacement, text, count=count)
        if n == 0:
            if applied is None and re.search(re.escape(replacement.split("\n")[0][:40]), text):
                continue
            failures.append(f"{path}: не найдено — {what}")

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

patch(build_config, [
    # Сервер по умолчанию: сотрудник не вводит адрес руками.
    #
    # Поля ровно два. Тип апстрима — \`defaultServers?: Server[]\`, где
    # \`Server = {name, url}\` (src/types/config.ts); \`order\` живёт в ДРУГОМ
    # типе, \`ConfigServer\`, и лишнее поле роняет сборку на \`check-build-config\`
    # (TS2353) — через шесть минут после начала, уже после \`npm ci\`.
    #
    # Взято оно было из ДОКСТРИНГА апстрима над этим же объектом, где \`order\`
    # описан. Докстринг у него устарел относительно типа: в комментарии-примере
    # строкой ниже стоят только name и url. Источник истины здесь — ТИП, а не
    # соседняя проза.
    (r"defaultServers: \[[^\]]*\]",
     'defaultServers: [\n        {\n            name: \'${BRAND_NAME}\',\n'
     '            url: \'${BRAND_DEFAULT_SERVER}\',\n        },\n    ]',
     "defaultServers"),

    # Один сервер и никаких других: это корпоративный клиент, а не универсальный.
    # Вернуть свободу подключения — поставить здесь true.
    (r"enableServerManagement: true", "enableServerManagement: false", "enableServerManagement"),

    (r"helpLink: DEFAULT_HELP_LINK", "helpLink: '${BRAND_SUPPORT_URL}'", "helpLink"),
    # «Ссылки нет» — ПУСТАЯ СТРОКА, а не \`null\`: у апстрима тип обоих полей
    # \`string\` (src/types/config.ts, BuildConfig), и \`null\` его нарушает. Читатели
    # сверяют их на истинность (\`isHttpLink(academyLink)\`, \`if (Config.upgradeLink)\`),
    # так что поведение то же, а соседние строки этого же объекта
    # (\`updateNotificationURL\`, \`macAppStoreUpdateURL\`) уже написаны пустой строкой.
    (r"academyLink: DEFAULT_ACADEMY_LINK", "academyLink: ''", "academyLink"),
    (r"upgradeLink: DEFAULT_UPGRADE_LINK", "upgradeLink: ''", "upgradeLink"),

    # Адреса обновлений вендора. Своего канала обновлений у нас пока нет,
    # поэтому уведомления выключаются целиком — звать на чужую сборку нельзя.
    (r"enableUpdateNotifications: true", "enableUpdateNotifications: false",
     "enableUpdateNotifications"),
    (r"updateNotificationURL: '[^']*'", "updateNotificationURL: ''", "updateNotificationURL"),
    (r"macAppStoreUpdateURL: '[^']*'", "macAppStoreUpdateURL: ''", "macAppStoreUpdateURL"),
    (r"windowsStoreUpdateURL: '[^']*'", "windowsStoreUpdateURL: ''", "windowsStoreUpdateURL"),
    (r"linuxUpdateURL: '[^']*'", "linuxUpdateURL: '${BRAND_SUPPORT_URL}'", "linuxUpdateURL"),
    (r"linuxGitHubReleaseURL: '[^']*'", "linuxGitHubReleaseURL: ''", "linuxGitHubReleaseURL"),

    # Схема глубоких ссылок должна совпадать с мобильной.
    (r"'mattermost',", "'${APP_SCHEME}',", "allowedProtocols"),
])

patch(electron_builder, [
    (r"appId: 'Mattermost\.Desktop'", "appId: '${APP_BUNDLE_ID_DESKTOP}'", "appId"),
    (r"appId: 'com\.Mattermost\.Desktop'", "appId: '${APP_BUNDLE_ID_DESKTOP}'", "appId (mac)"),

    # ИМЯ ФАЙЛА — ЛАТИНИЦЕЙ, имя ПРОДУКТА остаётся русским.
    #
    # Без этого сборка MSI ложится на WiX: candle отвечает «Icon/@Id не
    # найден». Цепочка длинная и целиком воспроизведена локально.
    # \`productMsiIdPrefix\` (MsiTarget.js:40) чистит имя файла регуляркой
    # \`[^\w.]\`, где \`\w\` в JS — только латиница; от «ЯдроЧат» не остаётся
    # НИЧЕГО, и сборщик уходит на запасной путь \`"App" + upgradeCode\`. А
    # upgradeCode у апстрима записан В ФИГУРНЫХ СКОБКАХ, поэтому идентификатор
    # выходит \`App{8523DAF0…}Icon.exe\` — скобки в Identifier недопустимы,
    # схема WiX отбрасывает атрибут, и candle говорит «не найден».
    #
    # У Mattermost это не выстреливает: их имя латиницей, до запасного пути
    # дело не доходит. Наше — доходит.
    #
    # Лечится сменой ИМЕНИ ФАЙЛА, а не названия: \`productFilename =
    # executableName ?? sanitizeFileName(productName)\` (appInfo.js:57), и
    # \`executableName\` объявлен у \`PlatformSpecificBuildOptions\`, от которого
    # наследуется \`WindowsConfiguration\`. Название продукта («ЯдроЧат») при
    # этом не трогается — его показывают меню «Пуск», заголовок окна и
    # установщик. Меняется то, что видно в проводнике и в диспетчере задач:
    # YadroChat.exe вместо ЯдроЧат.exe. Так и принято у русских программ.
    #
    # Замена написана ВСТАВКОЙ (совпадение — якорь в lookbehind, а новая строка
    # идёт первой в замене) НЕ ради красоты: проверка идемпотентности выше
    # смотрит на ПЕРВУЮ строку замены, и будь там «    win: {», непопавшая
    # замена молча сошла бы за уже применённую — эта строка есть всегда.
    (r"(?<=    win: \{\n)        target: \[",
     "        executableName: '${BRAND_NAME_LATIN}',\n        target: [",
     "executableName (win)",
     "executableName:"),

    # КОДОВАЯ СТРАНИЦА БАЗЫ MSI.
    #
    # Строки продукта у нас русские, а база MSI собирается в кодовой странице
    # 1252, где кириллицы нет: компоновщик отвечает LGHT0311 «A string was
    # provided with characters that are not available in the specified
    # database code page '1252'» — по строке на КАЖДУЮ русскую надпись.
    #
    # Объявленная в шаблоне \`Codepage="65001"\` не спасает: Windows Installer
    # UTF-8 не поддерживает, и значение отбрасывается. Для кириллицы годится
    # 1251 — проверено: все наши строки в неё ложатся, и ни одна не ложится
    # в 1252.
    #
    # Задать её можно ровно одним доступным нам рычагом — файлом локализации:
    #   Binder.cs:794  if (null != this.Localizer && -1 != this.Localizer.Codepage)
    #   Binder.cs:796      output.Codepage = this.Localizer.Codepage;
    # то есть локализация ПЕРЕБИВАЕТ объявление шаблона. А light.cs:265-274
    # без \`-cultures\` берёт НЕЙТРАЛЬНЫЙ файл (без Culture), если он есть, — и
    # только его; поэтому наш файл оказывается единственным и его кодовая
    # страница выигрывает. Пространство имён — v4: в \`wix.dll\` рядом лежат оба
    # и сообщение «The namespace '{0}' is out of date. It must be '{1}'».
    #
    # Путь АБСОЛЮТНЫЙ: light запускается с cwd во временном каталоге сборки,
    # и относительный путь до файла в форке оттуда не разрешается.
    (r"(?<=    msi: \{\n)        additionalWixArgs:",
     "        additionalLightArgs: ['-loc', require('path').join(__dirname, 'yadrochat.wxl')],\n"
     "        additionalWixArgs:",
     "additionalLightArgs (кодовая страница MSI)",
     "additionalLightArgs"),
])

# Хук упаковки апстрима ищет исполняемый файл ПО ИМЕНИ ВЕНДОРА, зашитому
# строкой: 'Mattermost.exe' и 'Mattermost.app'. У нас файл называется по
# productName, поэтому сборка ложилась в afterPack на ENOENT — уже после
# webpack и распаковки Electron, то есть на девятой минуте.
#
# Пропустить хук НЕЛЬЗЯ: он выставляет предохранители Electron (запрет
# ELECTRON_RUN_AS_NODE и --inspect, шифрование cookie, загрузка только из
# asar). Это защита, а не косметика.
#
# Правится тем же способом, каким апстрим УЖЕ делает ветку linux, — имя
# спрашивается у сборщика. Источник имени проверен по исходнику
# app-builder-lib 26.6.0: \`AppInfo.productFilename = executableName ??
# sanitizeFileName(productName)\` (out/appInfo.js), и файл называется
# \`\${productFilename}.exe\` в out/winPackager.js, \`.app\` — в out/macPackager.js.
patch(afterpack, [
    (r"return 'Mattermost\.exe';",
     "return \`\${context.packager.appInfo.productFilename}.exe\`;",
     "имя exe в afterpack.js"),
    (r"return 'Mattermost\.app';",
     "return \`\${context.packager.appInfo.productFilename}.app\`;",
     "имя app в afterpack.js"),
])

# ЗАГОЛОВКИ ОКОН. Их видно на панели задач Windows и в переключателе окон:
# у вендора там зашито «Mattermost Desktop App», и рядом с нашим значком это
# читается как чужая программа. Заголовки не берутся из productName — они
# записаны строками в конфиге сборки интерфейса, поэтому и правятся здесь.
#
# Замены НЕ единичные: одинаковых строк по дюжине на файл (у каждого окна
# настроек своя), поэтому count=0 — заменить все.
patch(webpack_renderer, [
    (r"title: 'Mattermost Desktop App'", "title: '${BRAND_NAME}'", "заголовок главного окна"),
    (r"title: 'Mattermost Desktop Settings'", "title: '${BRAND_NAME} — настройки'", "заголовок окна настроек"),
    (r"title: 'Mattermost Desktop Downloads'", "title: '${BRAND_NAME} — загрузки'", "заголовок окна загрузок"),
], count=0)

# НАЗВАНИЕ В ВЕРХНЕЙ ПАНЕЛИ показывается ВСЕГДА.
#
# У вендора оно выводится только когда серверов НЕТ ВООБЩЕ: место в панели
# занимают переключатель серверов и вкладки. У нас сервер один и он зашит,
# поэтому переключатель с вкладками — мёртвый груз (их убирает наш блок в
# index.scss), а панель без них оставалась бы вовсе безымянной.
patch(main_page, [
    (r"title=\{window\.process\.platform !== 'linux' && this\.state\.servers\.length === 0 \? this\.props\.appName : undefined\}",
     "title={this.props.appName}",
     "название в верхней панели"),
])

# ВХОД ВЕДЁТ НА НАШ ЭКРАН, а не на форму Mattermost.
#
# Когда сессии нет или она протухла, приложение чата уходит на \`/login\` — и
# делает это ВНУТРИ страницы, своим маршрутизатором, без запроса к серверу.
# Поэтому подменить адрес на обратном прокси недостаточно: прокси такого
# перехода не видит вовсе. Ловим его здесь и уводим окно на \`/vhod/\`.
#
# Оба события нужны: \`did-navigate\` — обычный переход, \`did-navigate-in-page\`
# — тот самый внутренний. Одного не хватает: первое молчит на внутреннем
# переходе, второе — на обычном.
# Стили ЯдроЧата накладываются ПОСЛЕ загрузки страницы, а не при создании
# вида: вставленные раньше, они пропадут на первой же навигации — Electron
# держит их за документом, а не за окном.
# Текст вида ДО наших правок — по нему сверяется, что вставляемый код не
# выдумывает полей у объектов вендора (проверка ниже).
with open(chat_view, encoding="utf-8") as fh:
    view_before = fh.read()

patch(chat_view, [
    # Импорт встаёт в группу псевдонимов вендора (\`app/…\`), а не между его
    # импортами из electron: у форка есть \`npm run check\` с правилом порядка
    # импортов, и сборка MSI его не гоняет — то есть замечено это будет не
    # нами и не сразу.
    (r"(?<=import NavigationManager from 'app/navigationManager';\n)",
     "import {applyYadroChatStyle} from 'app/views/yadrochatStyle';\n",
     "подключение стилей ЯдроЧата (импорт)",
     "applyYadroChatStyle} from"),
    # ВСЕ наши подписки — ОДНОЙ вставкой, а не тремя правилами.
    #
    # Не для краткости: правила одного вызова идут по очереди и правят общий
    # текст, поэтому правило, зацепленное за строку, которую создаёт правило
    # НИЖЕ, промахивается — что и случилось с подпиской на стили. Общий якорь
    # у всех троих — строка САМОГО ВЕНДОРА, и порядок между нами перестаёт
    # что-либо значить.
    (r"(?<=on\('update-target-url', this\.handleUpdateTarget\);\n)",
     "        this.webContentsView.webContents.on('did-navigate', this.handleAuthGate);\n"
     "        this.webContentsView.webContents.on('did-navigate-in-page', this.handleAuthGate);\n"
     "        this.webContentsView.webContents.on('did-finish-load', "
     "() => applyYadroChatStyle(this.webContentsView.webContents, this.log));\n",
     "подписки ЯдроЧата: перехват входа и наложение стилей",
     "'did-navigate', this.handleAuthGate"),
])

# Сам обработчик дописывается к классу. Не заменой, а вставкой перед соседним
# методом: заменять нечего — метода этого у апстрима нет вовсе.
#
# Отметка «уже вставлен» — ОБЪЯВЛЕНИЕ (\`private handleAuthGate =\`), а не голое
# имя. Голым именем эта проверка отменяла сама себя: подписки выше вставляются
# РАНЬШЕ и содержат \`this.handleAuthGate\`, то есть имя в тексте уже есть, и
# метод не дописывался НИКОГДА. Приложение при этом собиралось зелёным и
# падало на первом запуске: \`on('did-navigate', undefined)\`.
with open(chat_view, encoding="utf-8") as fh:
    view_text = fh.read()
if "private handleAuthGate =" not in view_text:
    marker = "    private handleUpdateTarget = "
    if marker not in view_text:
        failures.append(f"{chat_view}: не найдено — место для перехвата входа")
    else:
        view_text = view_text.replace(marker, AUTH_GATE + marker, 1)
        with open(chat_view, "w", encoding="utf-8") as fh:
            fh.write(view_text)

# Подписка без метода — это \`undefined\` в \`.on()\`, то есть отказ ПРИ ЗАПУСКЕ, а
# не при сборке: webpack о таком молчит, MSI выходит зелёным, и узнаёт об этом
# владелец. Поэтому каждое наше \`this.<имя>\`, отданное в \`.on()\`, сверяется
# здесь с объявлением В ТОМ ЖЕ файле. Правило общее, а не про один метод:
# следующий обработчик добавят так же и так же забудут.
with open(chat_view, encoding="utf-8") as fh:
    view_text = fh.read()
for handler in sorted(set(re.findall(r"\.on\('[^']+', this\.(handle\w+)\)", view_text))):
    if f"private {handler} =" not in view_text and f"{handler}(" not in view_text:
        failures.append(
            f"{chat_view}: подписка на this.{handler} есть, а самого метода нет — "
            f"это \`undefined\` в .on(), приложение упадёт при запуске")

# Сборка форка идёт BABEL'ом (\`webpack.config.base.js\`: babel-loader), а он
# ТИПЫ НЕ ПРОВЕРЯЕТ — просто срезает. \`npm run check-types\` есть, но путь
# упаковки MSI его не зовёт. Значит, обращение к несуществующему полю доедет
# до боевой машины и упадёт там: так \`this.view.server.url\` дал
# «Cannot read properties of undefined (reading 'url')» уже у владельца —
# у \`MattermostView\` есть \`serverId\`, а \`server\` нет вовсе.
#
# Заслон отсюда: наш код не смеет обращаться к полю объекта вендора, которым
# вендор в ЭТОМ ЖЕ файле не пользуется сам. Правило грубее компилятора, но
# работает без node_modules — и ловит ровно тот класс, который у нас уже
# дважды доехал до запуска.
for obj in ("view", "webContentsView"):
    ours = set(re.findall(rf"this\.{obj}\.(\w+)", AUTH_GATE))
    theirs = set(re.findall(rf"this\.{obj}\.(\w+)", view_before))
    for member in sorted(ours - theirs):
        failures.append(
            f"{chat_view}: наш код читает this.{obj}.{member}, а вендор такого поля "
            f"не знает — типы при сборке НЕ проверяются (babel), и это упадёт при запуске")

if failures:
    print("ОТКАЗ: часть замен не совпала — апстрим изменил эти места.", file=sys.stderr)
    for f in failures:
        print("  " + f, file=sys.stderr)
    print("\nПочините шаблоны в apply-desktop.sh. Пропустить нельзя: в сборке"
          "\nостанутся адреса и идентификаторы вендора.", file=sys.stderr)
    sys.exit(1)

for done in (build_config, electron_builder, afterpack, webpack_renderer, main_page,
             chat_view):
    print(f"  правлен {done}")
PY

# --- Верхняя панель ------------------------------------------------------------
# Убираются ПЕРЕКЛЮЧАТЕЛЬ СЕРВЕРОВ и ПОЛОСА ВКЛАДОК: сервер у нас один и зашит
# в сборку (enableServerManagement: false), поэтому оба элемента никуда не
# ведут — это переходы в один и тот же экран. Остаётся название по центру.
#
# Прячется СТИЛЯМИ, а не удалением разметки, намеренно: удаление трогало бы
# вендорский компонент, который апстрим правит каждый релиз, и каждое
# обновление давало бы конфликт слияния. `display: none` вдобавок убирает
# элементы из обхода табуляцией — спрятанное, но достижимое с клавиатуры было
# бы хуже показанного.
#
# Меню «⋮» ОСТАЁТСЯ: это единственный вход в настройки уведомлений, масштаб и
# «О программе». Убрать его — значит сделать настройки недостижимыми.
CSS_MARK="ЯдроЧат: верхняя панель"
if ! grep -q "$CSS_MARK" "$FORK/$RENDERER_CSS"; then
    cat >> "$FORK/$RENDERER_CSS" <<'CSS'

/* ЯдроЧат: верхняя панель — только название.
   Правку кладёт branding/apply-desktop.sh, руками не трогать. */
.ServerDropdownButton,
.TabBar,
.tab-bar-tabs {
  display: none !important;
}

.topBar .app-title {
  flex: 1;
  text-align: center;
}
CSS
    echo "  правлен $FORK/$RENDERER_CSS"
else
    echo "  $RENDERER_CSS — уже правлен"
fi

# --- Заставка запуска ----------------------------------------------------------
# Вендорский анимированный значок заменяется нашим логотипом. Геометрия НЕ
# переписывается руками: она берётся из `assets/logo-inverse.svg` — заставка
# тёмная, и светлая редакция надписи на ней не читается (замерено, 1.03:1).
#
# Вторую копию логотипа в TSX заводить нельзя: она разойдётся с SVG на первой
# же правке знака. Поэтому компонент СОБИРАЕТСЯ из файла, а атрибуты
# переводятся в camelCase, которого требует React.
python3 - "$BRAND_DIR/assets/logo-inverse.svg" "$FORK/$LOADING_ICON" <<'PY'
import re, sys

source, target = sys.argv[1], sys.argv[2]
svg = open(source, encoding="utf-8").read()

# Комментарий SVG в TSX не нужен: у компонента будет свой.
svg = re.sub(r"<!--.*?-->", "", svg, flags=re.S).strip()

def camel(match):
    name = match.group(1)
    # aria-* и data-* React принимает как есть — камелизация их сломает.
    if name.startswith(("aria-", "data-")):
        return match.group(0)
    head, *tail = name.split("-")
    return " " + head + "".join(part.capitalize() for part in tail) + "="

svg = re.sub(r"\s([a-z]+(?:-[a-z]+)+)=", camel, svg)

# `class` в React зовётся `className`; камелизация выше его не трогает —
# дефиса в нём нет.
svg = svg.replace(' class="', ' className="')

# Идентификаторы градиентов уникальны на документ, а заставка живёт в общем
# DOM вместе с остальным интерфейсом — префикс защищает от совпадения.
svg = svg.replace("yc-", "yadrochat-splash-")

# Заставка занимает фиксированное место: размеры задаёт стиль, не атрибуты.
svg = re.sub(r'\swidth="\d+"\s+height="\d+"', "", svg, count=1)

open(target, "w", encoding="utf-8").write('''// Логотип ЯдроЧата на заставке запуска.
//
// ФАЙЛ СОБИРАЕТСЯ branding/apply-desktop.sh из assets/logo-inverse.svg —
// руками не правится, следующий прогон брендинга перезапишет. Править надо
// ИСХОДНЫЙ SVG: вторая копия геометрии разошлась бы с ним на первой правке.
//
// Анимация — вращение орбиты вокруг ядра. Она уважает системную настройку
// «уменьшить движение»: у части людей крутящиеся элементы вызывают тошноту,
// и заставка — ровно то место, которое нельзя пропустить.
import React from 'react';

function YadroChatLoadingIcon() {
    return (
        <div className='yadrochat-splash'>
            <style>{`
                .yadrochat-splash svg { width: 168px; height: auto; }
                .yadrochat-splash .yadrochat-splash-orbit {
                    transform-origin: center;
                    animation: yadrochat-spin 2.6s linear infinite;
                }
                @keyframes yadrochat-spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
                @media (prefers-reduced-motion: reduce) {
                    .yadrochat-splash .yadrochat-splash-orbit { animation: none; }
                }
            `}</style>
''' + "            " + svg + '''
        </div>
    );
}

export default YadroChatLoadingIcon;
''')
print(f"  собран {target}")
PY

# --- Кодовая страница базы MSI -------------------------------------------------
# Разбор — рядом с заменой `additionalLightArgs` выше. Коротко: русские надписи
# не ложатся в кодовую страницу 1252, которой база MSI пользуется по умолчанию,
# и компоновщик отказывает по строке на каждую. Файл локализации перебивает
# объявление шаблона, а без `-cultures` берётся НЕЙТРАЛЬНЫЙ — поэтому Culture
# здесь намеренно НЕ задан.
#
# Строк файл не содержит вовсе: он существует ради одного атрибута.
cat > "$FORK/yadrochat.wxl" <<'WXL'
<?xml version="1.0" encoding="utf-8"?>
<!--
  Файл выкладывает branding/apply-desktop.sh «Ядра». Руками не править:
  следующий прогон брендинга перезапишет.

  Единственное назначение — кодовая страница базы MSI. Windows Installer не
  поддерживает UTF-8, поэтому объявленная в шаблоне electron-builder
  Codepage="65001" отбрасывается, база собирается в 1252, и русские надписи
  роняют компоновку с LGHT0311. 1251 покрывает кириллицу.

  Culture НЕ задан намеренно: без `-cultures` light берёт нейтральный файл,
  если он есть, и только его.
-->
<WixLocalization xmlns="http://wixtoolset.org/schemas/v4/wxl" Codepage="1251"/>
WXL
echo "  записан $FORK/yadrochat.wxl"

# --- Иконки ------------------------------------------------------------------
# Если рядом лежит ГОТОВЫЙ набор (`desktop-icons/`) — берём его. Так работает
# КОМПЛЕКТ, который разворачивают в форке без Linux и без растеризатора:
# картинки уже собраны, CI их только раскладывает.
#
# Набор собирается `make-desktop-icons.py --kit` при смене бренда. Второго
# источника правды это не заводит: и там, и там картинки родом из одних SVG.
if [ -d "$BRAND_DIR/desktop-icons" ]; then
    copied=0
    while IFS= read -r src; do
        rel="${src#"$BRAND_DIR"/desktop-icons/}"
        mkdir -p "$(dirname "$FORK/src/assets/$rel")"
        cp "$src" "$FORK/src/assets/$rel"
        copied=$((copied + 1))
    done < <(find "$BRAND_DIR/desktop-icons" -type f | sort)
    echo "  разложено иконок: $copied"

    # Апстрим вправе ДОБАВИТЬ иконку, которой в наборе нет, — и она молча
    # останется вендорской. Проверка дешёвая, а без неё в сборке оказался бы
    # чужой значок при полностью зелёном заслоне.
    missing=0
    while IFS= read -r vendor; do
        rel="${vendor#"$FORK"/src/assets/}"
        case "$rel" in
            *DMG_BG.png|yadrochat-icons.json) continue ;;
        esac
        [ -f "$BRAND_DIR/desktop-icons/$rel" ] || {
            [ "$missing" = 0 ] && echo "  ВНИМАНИЕ: у апстрима появились иконки, которых нет в наборе:"
            echo "    $rel"
            missing=$((missing + 1))
        }
    done < <(find "$FORK/src/assets" -type f \( -name '*.png' -o -name '*.ico' -o -name '*.icns' \) | sort)
    [ "$missing" = 0 ] || echo "  Пересоберите набор: ./make-desktop-icons.py --kit <форк>"
else
    echo "  готового набора иконок нет — соберите: ./make-desktop-icons.py \"$FORK\""
fi

# --- Конвейер сборки ----------------------------------------------------------
# Workflow и его заслон ЕДУТ В ФОРК, потому что CI форка не имеет доступа к
# приватному репозиторию «Ядра». Правятся они здесь и переносятся прогоном —
# правка копии в форке потеряется при следующем.
#
# Имя `yadrochat-*` намеренно: у апстрима два десятка своих workflow, и файл с
# его именем затёрся бы слиянием.
#
# Условие: внутри КОМПЛЕКТА, развёрнутого в форке, каталога `ci/` рядом нет —
# workflow там уже на месте, и копировать нечего.
if [ -d "$BRAND_DIR/../ci" ]; then
    mkdir -p "$FORK/.github/workflows"
    for platform in windows macos; do
        cp "$BRAND_DIR/../ci/build-$platform.yml" \
           "$FORK/.github/workflows/yadrochat-$platform.yml"
        echo "  положен .github/workflows/yadrochat-$platform.yml"
    done
    cp "$BRAND_DIR/../ci/verify-brand.py" "$FORK/yadrochat-verify-brand.py"
    chmod +x "$FORK/yadrochat-verify-brand.py"
    echo "  положен yadrochat-verify-brand.py"
fi

# --- Стили поверх интерфейса чата ---------------------------------------------
# Приложение чата берётся ГОТОВЫМ образом, собирать его самим мы не стали
# (docs/облик-клиента.md): цена такой сборки постоянная, а не разовая. Значит,
# всё, что можно поправить, правится стилями поверх — и у этого есть своя
# цена, которую надо назвать.
#
# ГЛАВНЫЙ РИСК: правила цепляются за имена классов ЧУЖОГО приложения. Вендор
# вправе их переименовать, и тогда правило перестанет совпадать — МОЛЧА.
# Интерфейс в этом месте вернётся к вендорскому виду, и заметить это можно
# только глазами, случайно, когда-нибудь.
#
# Поэтому рядом со стилями едет ПРОВЕРКА: после загрузки чата она спрашивает у
# страницы, нашлось ли по каждому опорному правилу хоть что-нибудь, и пишет в
# журнал имена промахнувшихся. Заслон, о котором не узнать, что он отвалился,
# — не заслон.
#
# Имена классов взяты ИЗ ИСХОДНИКОВ приложения чата, а не подобраны на глаз.
cat > "$FORK/$STYLE_FILE" <<'TS'
// Стили ЯдроЧата поверх интерфейса чата.
//
// ФАЙЛ СОБИРАЕТСЯ branding/apply-desktop.sh — руками не правится, следующий
// прогон брендинга перезапишет. Править надо скрипт.
//
// Цвета здесь НЕ задаются: их задаёт тема (vhod/app/theme.py), которую
// ЯдроВход ставит каждому сотруднику. Тут только то, чего темой не сделать —
// скругления, плотность и сокрытие того, что у нас не работает.

import type {WebContents} from 'electron';

/**
 * Опорные правила. Каждое — селектор и то, ЗАЧЕМ он: без второго через год
 * никто не вспомнит, можно ли это правило выбросить.
 *
 * Список нужен не только для документации: по нему идёт проверка совпадения
 * после загрузки.
 */
const ANCHORS: Array<{selector: string; why: string}> = [
    {selector: '#inviteMembersButton', why: 'приглашение вендора — оно шлёт письма, у нас свои ссылки'},
    {selector: '.SidebarLink', why: 'строка канала в колонке'},
    {selector: '.AdvancedTextEditor__body', why: 'поле ввода сообщения'},
];

const CSS = `
/* Приглашение вендора: оно зовёт по ПОЧТЕ, которой у наших сотрудников нет.
   Кнопка, ведущая в тупик, хуже отсутствующей — свои приглашения выдаются
   на /vhod/admin. */
#inviteMembersButton,
.SidebarChannelNavigator__inviteMembersLhsButton {
    display: none !important;
}

/* Строка канала: скругление и чуть больше воздуха. */
.SidebarLink {
    border-radius: 8px;
    margin: 1px 6px;
    padding-left: 10px;
}

/* Поле ввода: скруглённое, как на образце. */
.AdvancedTextEditor__body {
    border-radius: 12px;
}

/* Полосы прокрутки потоньше — в плотном списке каналов вендорская занимает
   заметную долю ширины. */
.SidebarNavContainer ::-webkit-scrollbar,
.sidebar--left ::-webkit-scrollbar {
    width: 8px;
}
`;

/**
 * Стили предназначены ПРИЛОЖЕНИЮ ЧАТА и никакой другой странице.
 *
 * Вид грузит не только чат: тот же did-finish-load приходит с нашего экрана
 * входа (/vhod/), со страницы ошибки и с внутренних страниц клиента.
 * Ни одного из опорных селекторов там нет по построению — и проба честно
 * доложила бы о трёх «пропавших» правилах при полностью исправном коде.
 * Ложная тревога, повторяющаяся при каждом входе, ровно так и убивает
 * проверку: её перестают читать до того, как она скажет правду.
 */
function isChatPage(url: string): boolean {
    try {
        const parsed = new URL(url);
        if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
            return false;
        }
        return !parsed.pathname.startsWith('/vhod/');
    } catch (e) {
        return false;
    }
}

/**
 * Наложить стили и проверить, что они на что-то легли.
 *
 * Проверка идёт ПОСЛЕ отрисовки (задержка), потому что список каналов
 * появляется не сразу: спроси раньше — получишь «не нашлось» на исправном
 * приложении, то есть ложную тревогу, которую перестанут читать.
 */
export async function applyYadroChatStyle(contents: WebContents, log: {warn: (...args: unknown[]) => void}) {
    if (!isChatPage(contents.getURL())) {
        return;
    }

    try {
        await contents.insertCSS(CSS);
    } catch (e) {
        log.warn('ЯдроЧат: стили не наложены', e);
        return;
    }

    setTimeout(() => {
        const probe = ANCHORS.map((a) => a.selector);
        contents.executeJavaScript(
            `(${JSON.stringify(probe)}).filter((s) => document.querySelector(s) === null)`,
            true,
        ).then((missed: string[]) => {
            if (!missed || missed.length === 0) {
                return;
            }
            for (const selector of missed) {
                const anchor = ANCHORS.find((a) => a.selector === selector);
                log.warn(
                    'ЯдроЧат: правило стиля ни на что не легло — ' + selector +
                    ' (' + (anchor ? anchor.why : '?') + '). Скорее всего, вендор ' +
                    'переименовал класс при обновлении: поправьте стили в ' +
                    'branding/apply-desktop.sh.',
                );
            }
        }).catch(() => {
            // Страница могла уйти раньше проверки — это не отказ.
        });
    }, 4000);
}
TS
echo "  собран $FORK/$STYLE_FILE"

cat <<EOF

Бренд применён к $FORK

  продукт:    $BRAND_NAME
  appId:      $APP_BUNDLE_ID_DESKTOP
  сервер:     $BRAND_DEFAULT_SERVER (управление серверами выключено)
  обновления: уведомления выключены — адреса вендора сняты

ДАЛЬШЕ:

  1. Иконки — ./make-desktop-icons.py "$FORK"
     Собирает весь набор: icon.ico (7 слоёв), icon.icns, значки трея для
     светлой и тёмной панели в трёх состояниях. Без этого сборка выйдет
     С ЛОГОТИПОМ ВЕНДОРА, и никакой ошибки при этом не будет.
     Нужны зависимости: pip install cairosvg pillow

ОСТАЛОСЬ РУКАМИ (скриптом не делается):

  2. Подпись сборок: publisherName в electron-builder.ts должен совпадать с
     CN вашего сертификата подписи кода Windows. Скрипт его НЕ подставляет —
     значение берётся из реального сертификата, а выдуманное даёт сборку,
     которую Windows пометит как ненадёжную.

  3. Первая сборка — из чистого клона, чтобы убедиться, что в ней не осталось
     имён вендора: grep -ri mattermost release/ по результату сборки.
EOF

