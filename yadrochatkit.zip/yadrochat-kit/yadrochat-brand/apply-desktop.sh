#!/usr/bin/env bash
# Применить бренд ЯдроЧата к форку mattermost/desktop (Electron).
#
#   ./apply-desktop.sh <путь-к-форку>
#
# Идемпотентен. Запускать ПОСЛЕ каждого подтягивания апстрима.
#
# Правятся три файла:
#   package.json                     — имя продукта, издатель, адреса
#   src/common/config/buildConfig.ts — сервер по умолчанию и адреса обновлений
#   electron-builder.ts              — appId сборки
#
# buildConfig.ts у апстрима так и подписан: «Build-time configuration. End-users
# can't change these parameters» — это штатная точка ребрендинга, а не наша
# самодеятельность.
#
# ОСОБО: у вендора там прописан СВОЙ адрес обновлений
# (releases.mattermost.com). Оставить его — значит звать наших сотрудников
# обновиться на сборку вендора, которая к нашему серверу не привязана. Скрипт
# снимает это обязательно, а не по желанию.
set -euo pipefail

# Путь к форку разрешается в АБСОЛЮТНЫЙ до того, как скрипт уйдёт в свой
# каталог. Иначе относительный аргумент начинает считаться от каталога скрипта:
# вызов `bash yadrochat-brand/apply-desktop.sh .` (ровно так его зовёт CI при
# работе из комплекта) искал бы форк ВНУТРИ комплекта и отказывал с «в форке
# нет package.json». Сборка при этом краснела бы на верном форке.
FORK="${1:-}"
[ -n "$FORK" ] || { echo "Использование: ./apply-desktop.sh <путь-к-форку-desktop>" >&2; exit 1; }
[ -d "$FORK" ] || { echo "ОТКАЗ: нет каталога $FORK" >&2; exit 1; }
FORK="$(cd "$FORK" && pwd)"

cd "$(dirname "$0")"
BRAND_DIR="$PWD"

# shellcheck source=brand.env
. "$BRAND_DIR/brand.env"

BUILD_CONFIG="src/common/config/buildConfig.ts"
for f in package.json "$BUILD_CONFIG" electron-builder.ts; do
    [ -f "$FORK/$f" ] || {
        echo "ОТКАЗ: в форке нет $f — раскладка апстрима изменилась." >&2
        echo "Сверьтесь с апстримом и почините пути здесь; молча пропустить нельзя:" >&2
        echo "сборка выйдет с брендом вендора." >&2
        exit 1
    }
done

APP_SCHEME="$(printf '%s' "$BRAND_NAME_LATIN" | tr '[:upper:]' '[:lower:]')"

# --- package.json -------------------------------------------------------------
python3 - "$FORK/package.json" <<PY
import json, sys

path = sys.argv[1]
with open(path, encoding="utf-8") as f:
    pkg = json.load(f)

pkg["name"] = "${APP_SCHEME}-desktop"
pkg["productName"] = "${BRAND_NAME}"
pkg["description"] = "${BRAND_DESCRIPTION}"
pkg["author"] = "${BRAND_VENDOR} <${BRAND_SUPPORT_EMAIL}>"
pkg["homepage"] = "${BRAND_SUPPORT_URL}"

with open(path, "w", encoding="utf-8") as f:
    json.dump(pkg, f, ensure_ascii=False, indent=2)
    f.write("\n")
print("  правлен package.json")
PY

# --- buildConfig.ts и electron-builder.ts -------------------------------------
# Замены ТОЧЕЧНЫЕ и с проверкой попадания. Переписать файл целиком нельзя: при
# обновлении апстрима мы бы молча потеряли его новые поля. Но и «заменить, если
# найдётся» нельзя тоже — непопавшая замена оставила бы адрес вендора в сборке
# и ничего не сказала. Поэтому каждая замена ОБЯЗАНА совпасть, иначе отказ.
python3 - "$FORK/$BUILD_CONFIG" "$FORK/electron-builder.ts" <<PY
import re, sys

build_config, electron_builder = sys.argv[1], sys.argv[2]
failures = []

def patch(path, rules):
    with open(path, encoding="utf-8") as f:
        text = f.read()

    for pattern, replacement, what in rules:
        text, n = re.subn(pattern, replacement, text, count=1)
        if n == 0:
            # Уже применённая замена — не отказ: скрипт идемпотентен.
            if re.search(re.escape(replacement.split("\n")[0][:40]), text):
                continue
            failures.append(f"{path}: не найдено — {what}")

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

patch(build_config, [
    # Сервер по умолчанию: сотрудник не вводит адрес руками.
    (r"defaultServers: \[[^\]]*\]",
     'defaultServers: [\n        {\n            name: \'${BRAND_NAME}\',\n'
     '            url: \'${BRAND_DEFAULT_SERVER}\',\n            order: 0,\n        },\n    ]',
     "defaultServers"),

    # Один сервер и никаких других: это корпоративный клиент, а не универсальный.
    # Вернуть свободу подключения — поставить здесь true.
    (r"enableServerManagement: true", "enableServerManagement: false", "enableServerManagement"),

    (r"helpLink: DEFAULT_HELP_LINK", "helpLink: '${BRAND_SUPPORT_URL}'", "helpLink"),
    (r"academyLink: DEFAULT_ACADEMY_LINK", "academyLink: null", "academyLink"),
    (r"upgradeLink: DEFAULT_UPGRADE_LINK", "upgradeLink: null", "upgradeLink"),

    # Адреса обновлений вендора. Своего канала обновлений у нас пока нет,
    # поэтому уведомления выключаются целиком — звать на чужую сборку нельзя.
    (r"enableUpdateNotifications: true", "enableUpdateNotifications: false",
     "enableUpdateNotifications"),
    (r"updateNotificationURL: '[^']*'", "updateNotificationURL: ''", "updateNotificationURL"),
    (r"macAppStoreUpdateURL: '[^']*'", "macAppStoreUpdateURL: ''", "macAppStoreUpdateURL"),
    (r"windowsStoreUpdateURL: '[^']*'", "windowsStoreUpdateURL: ''", "windowsStoreUpdateURL"),
    (r"linuxUpdateURL: '[^']*'", "linuxUpdateURL: '${BRAND_SUPPORT_URL}'", "linuxUpdateURL"),
    (r"linuxGitHubReleaseURL: '[^']*'", "linuxGitHubReleaseURL: ''", "linuxGitHubReleaseURL"),

    # Схема глубоких ссылок должна совпадать с мобильной.
    (r"'mattermost',", "'${APP_SCHEME}',", "allowedProtocols"),
])

patch(electron_builder, [
    (r"appId: 'Mattermost\.Desktop'", "appId: '${APP_BUNDLE_ID_DESKTOP}'", "appId"),
    (r"appId: 'com\.Mattermost\.Desktop'", "appId: '${APP_BUNDLE_ID_DESKTOP}'", "appId (mac)"),
])

if failures:
    print("ОТКАЗ: часть замен не совпала — апстрим изменил эти места.", file=sys.stderr)
    for f in failures:
        print("  " + f, file=sys.stderr)
    print("\nПочините шаблоны в apply-desktop.sh. Пропустить нельзя: в сборке"
          "\nостанутся адреса и идентификаторы вендора.", file=sys.stderr)
    sys.exit(1)

print(f"  правлен {build_config}")
print(f"  правлен {electron_builder}")
PY

# --- Иконки ------------------------------------------------------------------
# Если рядом лежит ГОТОВЫЙ набор (`desktop-icons/`) — берём его. Так работает
# КОМПЛЕКТ, который разворачивают в форке без Linux и без растеризатора:
# картинки уже собраны, CI их только раскладывает.
#
# Набор собирается `make-desktop-icons.py --kit` при смене бренда. Второго
# источника правды это не заводит: и там, и там картинки родом из одних SVG.
if [ -d "$BRAND_DIR/desktop-icons" ]; then
    copied=0
    while IFS= read -r src; do
        rel="${src#"$BRAND_DIR"/desktop-icons/}"
        mkdir -p "$(dirname "$FORK/src/assets/$rel")"
        cp "$src" "$FORK/src/assets/$rel"
        copied=$((copied + 1))
    done < <(find "$BRAND_DIR/desktop-icons" -type f | sort)
    echo "  разложено иконок: $copied"

    # Апстрим вправе ДОБАВИТЬ иконку, которой в наборе нет, — и она молча
    # останется вендорской. Проверка дешёвая, а без неё в сборке оказался бы
    # чужой значок при полностью зелёном заслоне.
    missing=0
    while IFS= read -r vendor; do
        rel="${vendor#"$FORK"/src/assets/}"
        case "$rel" in
            *DMG_BG.png|yadrochat-icons.json) continue ;;
        esac
        [ -f "$BRAND_DIR/desktop-icons/$rel" ] || {
            [ "$missing" = 0 ] && echo "  ВНИМАНИЕ: у апстрима появились иконки, которых нет в наборе:"
            echo "    $rel"
            missing=$((missing + 1))
        }
    done < <(find "$FORK/src/assets" -type f \( -name '*.png' -o -name '*.ico' -o -name '*.icns' \) | sort)
    [ "$missing" = 0 ] || echo "  Пересоберите набор: ./make-desktop-icons.py --kit <форк>"
else
    echo "  готового набора иконок нет — соберите: ./make-desktop-icons.py \"$FORK\""
fi

# --- Конвейер сборки ----------------------------------------------------------
# Workflow и его заслон ЕДУТ В ФОРК, потому что CI форка не имеет доступа к
# приватному репозиторию «Ядра». Правятся они здесь и переносятся прогоном —
# правка копии в форке потеряется при следующем.
#
# Имя `yadrochat-*` намеренно: у апстрима два десятка своих workflow, и файл с
# его именем затёрся бы слиянием.
#
# Условие: внутри КОМПЛЕКТА, развёрнутого в форке, каталога `ci/` рядом нет —
# workflow там уже на месте, и копировать нечего.
if [ -d "$BRAND_DIR/../ci" ]; then
    mkdir -p "$FORK/.github/workflows"
    for platform in windows macos; do
        cp "$BRAND_DIR/../ci/build-$platform.yml" \
           "$FORK/.github/workflows/yadrochat-$platform.yml"
        echo "  положен .github/workflows/yadrochat-$platform.yml"
    done
    cp "$BRAND_DIR/../ci/verify-brand.py" "$FORK/yadrochat-verify-brand.py"
    chmod +x "$FORK/yadrochat-verify-brand.py"
    echo "  положен yadrochat-verify-brand.py"
fi

cat <<EOF

Бренд применён к $FORK

  продукт:    $BRAND_NAME
  appId:      $APP_BUNDLE_ID_DESKTOP
  сервер:     $BRAND_DEFAULT_SERVER (управление серверами выключено)
  обновления: уведомления выключены — адреса вендора сняты

ДАЛЬШЕ:

  1. Иконки — ./make-desktop-icons.py "$FORK"
     Собирает весь набор: icon.ico (7 слоёв), icon.icns, значки трея для
     светлой и тёмной панели в трёх состояниях. Без этого сборка выйдет
     С ЛОГОТИПОМ ВЕНДОРА, и никакой ошибки при этом не будет.
     Нужны зависимости: pip install cairosvg pillow

ОСТАЛОСЬ РУКАМИ (скриптом не делается):

  2. Подпись сборок: publisherName в electron-builder.ts должен совпадать с
     CN вашего сертификата подписи кода Windows. Скрипт его НЕ подставляет —
     значение берётся из реального сертификата, а выдуманное даёт сборку,
     которую Windows пометит как ненадёжную.

  3. Первая сборка — из чистого клона, чтобы убедиться, что в ней не осталось
     имён вендора: grep -ri mattermost release/ по результату сборки.
EOF
